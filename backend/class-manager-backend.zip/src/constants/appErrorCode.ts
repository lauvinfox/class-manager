const enum AppErrorCode {
  InvalidAccessToken = "INVALID_ACCESS_TOKEN",
}

export default AppErrorCode;
